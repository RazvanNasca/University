import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
public class Cont {

    Lock lockRON = new ReentrantLock();

    Object lR = new Object();

    private int soldLei = 0;

    Cont(int soldLei){
        this.soldLei = soldLei;
    }

    //synchronized void add(){ // Solutia 1, simpla dar bruta si lenta
    void depundeLei(){

       synchronized(lR) { /// Solutia 2, mai granulara
           for (int i = 0; i < 1000; i++) 
               sold++;
       }

        lockRON.lock();
        //lockEUR.lock();
            for (int i = 0; i < 1000; i++) {
                soldLei++;
            }
        lockRON.unlock();
    }

    void retrageLei(){
        synchronized (this) {
            for (int i = 0; i < 1000; i++)
                soldLei -= 1;
        }
    }

    public int getSold(){
        return  soldLei;
    }
}
