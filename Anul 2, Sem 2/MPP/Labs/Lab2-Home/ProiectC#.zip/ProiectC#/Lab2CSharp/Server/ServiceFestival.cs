﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Persistance;
using Model;
using Services;

namespace Server
{
    class ServiceFestival : IFestivalServices
    {
        IRepoUser userRepo;
        IRepoShow showRepo;
        IRepoBuyer buyerRepo;
        private readonly IDictionary<String, IFestivalObserver> loggedUsers;

        public ServiceFestival(IRepoBuyer buyerRepo, IRepoShow showRepo, IRepoUser userRepo)
        {
            this.buyerRepo = buyerRepo;
            this.showRepo = showRepo;
            this.userRepo = userRepo;
            loggedUsers = new Dictionary<String, IFestivalObserver>();
        }

        public User Login(User user, IFestivalObserver client)
        {
            try
            {
                User userOK =  userRepo.FindOne(user.Name);

                if(userOK == null)
                    throw new FestivalException("Authentication failed!");

                if (userOK.Password != user.Password)
                    throw new FestivalException("Wrong password!");

                if (userOK != null)
                {
                    if (loggedUsers.ContainsKey(user.ID))
                        throw new FestivalException("User already logged in.");
                    loggedUsers[user.ID] = client;
                    /*notifyUsersLoggedIn(user);*/
                    return user;
                }
                    
            }
            catch (Exception e)
            {
                throw new FestivalException("Authentication failed " + e);
            }
            return user;
        }

        private void notifyUsersLoggedIn(User user)
        {
            foreach (string u in loggedUsers.Keys)
            {
                Console.WriteLine("Notify user " + u);
                IFestivalObserver client = loggedUsers[u];
                Task.Run(() => client.userLoggedIn(user));
            }
        }

        public List<Show> getAllShows()
        {
            return (List<Show>)showRepo.FindAll();
        }


        public List<Buyer> getAllBuyers()
        {
            return (List<Buyer>)buyerRepo.FindAll();
        }


        public List<Show> searchArtistByDate(DateTime date)
        {
                try{
                    return (List<Show>)showRepo.SearchArtistByDate(date);
                }
                catch(Exception e)
                {
                    throw new Exception("Repo error" + e);
            }
        }


        public Buyer saveBuyer(String name, int noTickets, Show Show)
        {
            try{
                Buyer buyer = new Buyer(name, noTickets, Show);
                List<Buyer> list = (List<Buyer>)getAllBuyers();
                buyer.ID = list.Count() + 1;
                Buyer finalBuyer =  buyerRepo.Save(buyer);
                finalBuyer.show.RemainingTickets -= noTickets; 

                /// notify all users 
                notifyUsersShow(finalBuyer.show);

                return finalBuyer;
            }
            catch(Exception e)
            {
                throw new Exception("Repo error" + e);
            }
        }

        private void notifyUsersShow(Show show)
        {
           
            foreach (string u in loggedUsers.Keys)
            {
                Console.WriteLine("Notify user " + u);
                IFestivalObserver client = loggedUsers[u];
                Task.Run(() => client.showUpdate(show));
            }
        }


        public void logout(User user, IFestivalObserver client)
        {
            IFestivalObserver localClient = loggedUsers[user.ID];
            if (localClient == null)
                throw new FestivalException("User " + user.ID + " is not logged in.");
            loggedUsers.Remove(user.ID);
            notifyUsersLoggedOut(user);
        }

        private void notifyUsersLoggedOut(User user)
        {
            IEnumerable<User> users = userRepo.FindAll();
            foreach (User us in users)
            {
                if (loggedUsers.ContainsKey(us.ID))
                {
                    IFestivalObserver chatClient = loggedUsers[us.ID];
                    Task.Run(() => chatClient.userLoggedOut(user));
                }
            }
        }

        public User[] getLoggedUsers()
        {
            IEnumerable<User> users = userRepo.FindAll();
            IList<User> result = new List<User>();
            foreach (User user in users)
            {
                if (loggedUsers.ContainsKey(user.ID))
                { 
                    result.Add(new User(user.ID, user.Password));
                    Console.WriteLine("+" + user.ID);
                }
            }
            Console.WriteLine("Size " + result.Count);
            return result.ToArray();
        }
    }
}
