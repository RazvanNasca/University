﻿using Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace RestClient
{
    class Program
    {
        static readonly HttpClient client = new HttpClient();

        static void Main(string[] args)
        {
            RunAsync().Wait();
        }

        private static Show show;

        static async Task RunAsync()
        {
            client.BaseAddress = new Uri("http://localhost:8080/festival/shows");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            string id = "1";
            Console.WriteLine("Getting show {0}...", id);
            Show result = await GetShowAsync("http://localhost:8080/festival/shows/" + id);
            Console.WriteLine("Got show: {0}", result);
            Console.WriteLine();

            Console.WriteLine("Getting all shows...");
            List<Show> shows = await GetAllShowsAsync("http://localhost:8080/festival/shows");
            foreach (Show s in shows)
                Console.WriteLine(s);
            Console.WriteLine();

           

            Console.WriteLine("Press <enter> to exit...");
            Console.ReadKey();
        }

        static async Task<Show> GetShowAsync(string path)
        {
            Show show = null;
            HttpResponseMessage response = await client.GetAsync(path);
            if (response.IsSuccessStatusCode)
            {
                string text = await response.Content.ReadAsStringAsync();
                show = JsonConvert.DeserializeObject<Show>(text);
            }
            System.Threading.Thread.Sleep(1000);
            return show;
        }

        static async Task<List<Show>> GetAllShowsAsync(string path)
        {
            List<Show> shows = null;
            HttpResponseMessage response = await client.GetAsync(path);
            if (response.IsSuccessStatusCode)
            {
                string text = await response.Content.ReadAsStringAsync();
                shows = JsonConvert.DeserializeObject<List<Show>>(text);
            }
            System.Threading.Thread.Sleep(1000);
            return shows;
        }

        static async Task<Show> CreateShow(string path, Show s)
        {
            string json = DeserializeJson(s);

            var httpContent = new StringContent(json, Encoding.UTF8, "application/json");
            HttpResponseMessage response = await client.PostAsync(path, httpContent);

            Show savedShow = null;
            if (response.IsSuccessStatusCode)
            {
                string text = await response.Content.ReadAsStringAsync();
                savedShow = JsonConvert.DeserializeObject<Show>(text);
            }
            System.Threading.Thread.Sleep(1000);
            return savedShow;
        }

        static async void DeleteShow(string path)
        {
            await client.DeleteAsync(path);
            System.Threading.Thread.Sleep(1000);
        }

        static async void UpdateShow(string path, Show s)
        {
            string json = DeserializeJson(s);
            var httpContent = new StringContent(json, Encoding.UTF8, "application/json");
            await client.PutAsync(path, httpContent);
            System.Threading.Thread.Sleep(1000);
        }

        static string DeserializeJson(Show t)
        {
            string json = JsonConvert.SerializeObject(t);

            Dictionary<string, string> dict = json.Substring(1, json.Length - 2)
                .Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(part => part.Split(new[] { ':' }, 2))
                .ToDictionary(split => split[0], split => split[1]);

            foreach (var key in dict.Keys.ToList())
            {
                var newKey = key.First() + key.Substring(1, 1).ToLower() + key.Substring(2);
                dict.Add(newKey, dict[key]);
                dict.Remove(key);
            }

            var entries = dict.Select(d =>
                string.Format("{0}:{1}", d.Key, d.Value));
            return "{" + string.Join(",", entries) + "}";
        }
    }
}

