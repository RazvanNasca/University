﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace Services
{
    public interface IFestivalServices
    {
        List<Show> getAllShows();

        List<Buyer> getAllBuyers();

        User Login(User user, IFestivalObserver client);

        void logout(User user, IFestivalObserver client);

        List<Show> searchArtistByDate(DateTime date);

        Buyer saveBuyer(String name, int noTickets, Show Show);

        User[] getLoggedUsers();
    }
}
