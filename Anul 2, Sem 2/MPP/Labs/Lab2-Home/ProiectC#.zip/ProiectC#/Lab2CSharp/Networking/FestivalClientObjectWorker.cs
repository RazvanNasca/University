﻿using Model;
using Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Networking
{
	public class FestivalClientWorker : IFestivalObserver //, Runnable
	{
		private IFestivalServices server;
		private TcpClient connection;

		private NetworkStream stream;
		private IFormatter formatter;
		private volatile bool connected;
		public FestivalClientWorker(IFestivalServices server, TcpClient connection)
		{
			this.server = server;
			this.connection = connection;
			try
			{
				stream = connection.GetStream();
				formatter = new BinaryFormatter();
				connected = true;
			}
			catch (Exception e)
			{
				Console.WriteLine(e.StackTrace);
			}
		}

		public virtual void run()
		{
			while (connected)
			{
				try
				{
					object request = formatter.Deserialize(stream);
					object response = handleRequest((Request)request);
					if (response != null)
					{
						sendResponse((Response)response);
					}
				}
				catch (Exception e)
				{
					Console.WriteLine(e.StackTrace);
				}

				try
				{
					Thread.Sleep(1000);
				}
				catch (Exception e)
				{
					Console.WriteLine(e.StackTrace);
				}
			}
			try
			{
				stream.Close();
				connection.Close();
			}
			catch (Exception e)
			{
				Console.WriteLine("Error " + e);
			}
		}

        public void showUpdate(Show show)
        {
			Console.WriteLine("Show updated " + show);
			try
			{
				sendResponse(new SaveBuyerResponse(show));
			}
			catch (Exception e)
			{
				Console.WriteLine(e.StackTrace);
			}
		}


        public virtual void userLoggedIn(User user)
		{
			Console.WriteLine("User logged in " + user);
			try
			{
				sendResponse(new UserLoggedInResponse(user));
			}
			catch (Exception e)
			{
				Console.WriteLine(e.StackTrace);
			}
		}
		public virtual void userLoggedOut(User user)
		{
			Console.WriteLine("Friend logged out " + user);
			try
			{
				sendResponse(new UserLoggedOutResponse(user));
			}
			catch (Exception e)
			{
				Console.WriteLine(e.StackTrace);
			}
		}

		private Response handleRequest(Request request)
		{
			Response response = null;
			if (request is LoginRequest)
			{
				Console.WriteLine("Login request...");
				LoginRequest logReq = (LoginRequest)request;
				User user = logReq.User;
				try
				{
					lock (server)
					{
						server.Login(user, this);
					}
					return new UserLoggedInResponse(user);
					//return new OkResponse();
				}
				catch (FestivalException e)
				{
					connected = false;
					return new ErrorResponse(e.Message);
				}
			}
			if (request is LogoutRequest)
			{
				Console.WriteLine("Logout request...");
				LogoutRequest logReq = (LogoutRequest)request;
				User user = logReq.User;
				try
				{
					lock (server)
					{
						server.logout(user, this);
					}
					connected = false;
					return new OkResponse();

				}
				catch (FestivalException e)
				{
					return new ErrorResponse(e.Message);
				}
			}

			if (request is GetAllShowsRequest)
			{
				Console.WriteLine("GetAllShowsRequest Request...");
				GetAllShowsRequest getReq = (GetAllShowsRequest)request;
				try
				{
					List<Show> shows = new List<Show>();
					lock (server)
					{
						shows = server.getAllShows();
					}
					return new GetAllShowsResponse(shows);
				}
				catch (FestivalException e)
				{
					return new ErrorResponse(e.Message);
				}
			}

			if (request is SaveBuyerRequest)
			{
				Console.WriteLine("SaveBuyerRequest Request...");
				SaveBuyerRequest getReq = (SaveBuyerRequest)request;
				Buyer buyer = getReq.Buyer;
				try
				{
					Show show;
					lock (server)
					{
						show = server.saveBuyer(buyer.Name, buyer.noTickets, buyer.show).show;
					}
					//return new SaveBuyerResponse(show);
					return new OkResponse();
				}
				catch (FestivalException e)
				{
					return new ErrorResponse(e.Message);
				}
			}

			if (request is GetFilteredShowsRequest)
			{
				Console.WriteLine("GetFilteredShowsRequest Request...");
				GetFilteredShowsRequest getReq = (GetFilteredShowsRequest)request;
				DateTime date = getReq.Date;
				try
				{
					List<Show> shows = new List<Show>();
					lock (server)
					{
						shows = server.searchArtistByDate(date);
					}
					return new GetFilteredShowsResponse(shows);
				}
				catch (FestivalException e)
				{
					return new ErrorResponse(e.Message);
				}
			}

			if (request is GetLoggedUsersRequest)
			{
				Console.WriteLine("GetLoggedUsers Request...");
				GetLoggedUsersRequest getReq = (GetLoggedUsersRequest)request;
				try
				{
					User[] users;
					lock (server)
					{
						users = server.getLoggedUsers();
					}
					return new GetLoggedUsersResponse(users);
				}
				catch (FestivalException e)
				{
					return new ErrorResponse(e.Message);
				}
			}

			return response;
		}

		private void sendResponse(Response response)
		{
			Console.WriteLine("sending response " + response);
			lock(stream)
            {
				formatter.Serialize(stream, response);
				stream.Flush();
			}
		}
	}
}
