﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Microsoft.Data.Sqlite;

namespace Lab2CSharp
{
	public class SqliteConnectionFactory : ConnectionFactory
	 {
		 public override IDbConnection createConnection()
		 {

			//Windows Sqlite Connection, fisierul .db ar trebuie sa fie in directorul debug/bin
			String connectionString = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
			return new SQLiteConnection(connectionString);
		 }
	 }
}
