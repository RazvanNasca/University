﻿using Model;
using Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Networking
{
	public class FestivalServerProxy : IFestivalServices
	{
		private string host;
		private int port;

		private IFestivalObserver client;

		private NetworkStream stream;

		private IFormatter formatter;
		private TcpClient connection;

		private Queue<Response> responses;
		private volatile bool finished;
		private EventWaitHandle _waitHandle;
		public FestivalServerProxy(string host, int port)
		{
			this.host = host;
			this.port = port;
			responses = new Queue<Response>();
		}

		public virtual User Login(User user, IFestivalObserver client)
		{
			initializeConnection();
			sendRequest(new LoginRequest(user));
			Response response = readResponse();
			if (response is ErrorResponse)
			{
				ErrorResponse err = (ErrorResponse)response;
				closeConnection();
				throw new FestivalException(err.Message);
			}
			this.client = client;
			UserLoggedInResponse resp = (UserLoggedInResponse)response;
			return resp.User;
		}

		public Buyer saveBuyer(string name, int noTickets, Show Show)
		{
			Buyer buyer = new Buyer(name, noTickets, Show);
			sendRequest(new SaveBuyerRequest(buyer));
			Response response = readResponse();
			if (response is ErrorResponse)
			{
				ErrorResponse err = (ErrorResponse)response;
				throw new FestivalException(err.Message);
			}
			return buyer;
		}

		public virtual void logout(User user, IFestivalObserver client)
		{
			sendRequest(new LogoutRequest(user));
			Response response = readResponse();
			closeConnection();
			if (response is ErrorResponse)
			{
				ErrorResponse err = (ErrorResponse)response;
				throw new FestivalException(err.Message);
			}
		}

		public virtual User[] getLoggedUsers()
		{
			sendRequest(new GetLoggedUsersRequest());
			Response response = readResponse();
			if (response is ErrorResponse)
			{
				ErrorResponse err = (ErrorResponse)response;
				throw new FestivalException(err.Message);
			}
			GetLoggedUsersResponse resp = (GetLoggedUsersResponse)response;
			User[] users = resp.Users;
			return users;
		}

		public List<Show> getAllShows()
		{
			sendRequest(new GetAllShowsRequest());
			Response response = readResponse();
			if (response is ErrorResponse)
			{
				ErrorResponse err = (ErrorResponse)response;
				throw new FestivalException(err.Message);
			}
			GetAllShowsResponse resp = (GetAllShowsResponse)response;
			List<Show> shows = resp.Shows;
			return shows;
		}

		public List<Buyer> getAllBuyers()
		{
			throw new NotImplementedException();
		}

		public List<Show> searchArtistByDate(DateTime date)
		{
			sendRequest(new GetFilteredShowsRequest(date));
			Response response = readResponse();
			if (response is ErrorResponse)
			{
				ErrorResponse err = (ErrorResponse)response;
				throw new FestivalException(err.Message);
			}
			GetFilteredShowsResponse resp = (GetFilteredShowsResponse)response;
			List<Show> shows = resp.Shows;
			return shows;
		}

	

		private void closeConnection()
		{
			finished = true;
			try
			{
				stream.Close();
				//output.close();
				connection.Close();
				_waitHandle.Close();
				client = null;
			}
			catch (Exception e)
			{
				Console.WriteLine(e.StackTrace);
			}

		}

		private void sendRequest(Request request)
		{
			try
			{
				formatter.Serialize(stream, request);
				stream.Flush();
			}
			catch (Exception e)
			{
				throw new FestivalException("Error sending object " + e);
			}

		}

		private Response readResponse()
		{
			Response response = null;
			try
			{
				_waitHandle.WaitOne();
				lock (responses)
				{
					//Monitor.Wait(responses); 
					response = responses.Dequeue();
				}
			}
			catch (Exception e)
			{
				Console.WriteLine(e.StackTrace);
			}
			return response;
		}
		private void initializeConnection()
		{
			try
			{
				connection = new TcpClient(host, port);
				stream = connection.GetStream();
				formatter = new BinaryFormatter();
				finished = false;
				_waitHandle = new AutoResetEvent(false);
				startReader();
			}
			catch (Exception e)
			{
				Console.WriteLine(e.StackTrace);
			}
		}
		private void startReader()
		{
			Thread tw = new Thread(run);
			tw.Start();
		}


		private void handleUpdate(UpdateResponse update)
		{
            if (update is UserLoggedInResponse)
            {

                UserLoggedInResponse usUpd = (UserLoggedInResponse)update;
                User user = usUpd.User;
                Console.WriteLine("User logged in " + user);
                try
                {
                    client.userLoggedIn(user);
                }
                catch (FestivalException e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }


            if (update is UserLoggedOutResponse)
			{
				UserLoggedOutResponse usOutRes = (UserLoggedOutResponse)update;
				User user = usOutRes.User;
				Console.WriteLine("User logged out " + user);
				try
				{
					client.userLoggedOut(user);
				}
				catch (FestivalException e)
				{
					Console.WriteLine(e.StackTrace);
				}
			}

			if (update is SaveBuyerResponse)
			{
				SaveBuyerResponse response = (SaveBuyerResponse)update;
				Show show = response.Show;
				Console.WriteLine("Show updated: " + show.ID);
				try
				{
					client.showUpdate(show);
				}
				catch (Exception e)
				{
					Console.WriteLine(e.StackTrace);
				}
			}
		}
		public virtual void run()
		{
			while (!finished)
			{
				try
				{
					object response = formatter.Deserialize(stream);
					Console.WriteLine("response received " + response);
					if (response is UpdateResponse)
					{
						handleUpdate((UpdateResponse)response);
					}
					else
					{
						lock (responses)
						{
							responses.Enqueue((Response)response);
						}
						_waitHandle.Set();
					}
				}
				catch (Exception e)
				{
					Console.WriteLine("Reading error " + e);
				}

			}
		}
 
    }
}
