﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    [Serializable]
    public class Buyer : Entity<int>
    {
        public Buyer(string name, int noTickets, Show show)
        {
            Name = name;
            this.noTickets = noTickets;
            this.show = show;
        }

        public string Name { get; set; }
        public int noTickets { get; set; }
        public Show show { get; set; }


    }
}
