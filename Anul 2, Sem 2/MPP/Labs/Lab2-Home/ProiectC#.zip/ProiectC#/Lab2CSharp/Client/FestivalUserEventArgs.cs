﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
    public enum FestivalUserEvent
    {
        UserLoggedIn, UserLoggedOut, ShowUpdated
    };
    public class FestivalUserEventArgs : EventArgs
    {
        private readonly FestivalUserEvent userEvent;
        private readonly Object data;

        public FestivalUserEventArgs(FestivalUserEvent userEvent, object data)
        {
            this.userEvent = userEvent;
            this.data = data;
        }

        public FestivalUserEvent UserEventType
        {
            get { return userEvent; }
        }

        public object Data
        {
            get { return data; }
        }
    }
}
