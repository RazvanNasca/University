﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Windows.Forms;
using Hashtable = System.Collections.Hashtable;
using Services;
using Networking;

namespace Client
{
    class StartFestivalClient
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
       
            IFestivalServices server = new FestivalServerProxy("127.0.0.1", 55555);
            FestivalClientCtrl ctrl = new FestivalClientCtrl(server);
            LoginForm win = new LoginForm(ctrl);
            Application.Run(win);
        }
    }
}
