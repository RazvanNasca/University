﻿/*using Lab2CSharp.Domain;
using log4net;*/
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace Persistance
{
    public class BuyerDBRepo : IRepoBuyer
    {
        //private static readonly ILog log = LogManager.GetLogger("BuyerDBRepo");
        public BuyerDBRepo()
        {
           /* log.Info("Creating BuyerDBRepo");*/
        }
        public IEnumerable<Buyer> FindAll()
        {
            //log.InfoFormat("Entering findAll with value {0}");
            IDbConnection con = DBUtils.getConnection();

            IList<Buyer> buyers = new List<Buyer>();

            using (var comm = con.CreateCommand())
            {
                comm.CommandText = "select * from Buyers B inner join BuyerShow BS on B.idBuyer = BS.idBuyer inner join Shows S on S.idShow = BS.idShow";

                using (var dataR = comm.ExecuteReader())
                {
                    while (dataR.Read())
                    {
                        int idBuyer = dataR.GetInt32(0);
                        int noTickets = dataR.GetInt32(1);
                        String name = dataR.GetString(2);

                        int idShow = dataR.GetInt32(5);
                        String artistName = dataR.GetString(6);
                        String place = dataR.GetString(7);
                        int remainingTickets = dataR.GetInt32(8);
                        DateTime date = DateTime.ParseExact(dataR.GetString(9), "yyyy-MM-dd HH:mm", null);

                        Show show = new Show(idShow, artistName, date, place, remainingTickets);
                        Buyer buyer = new Buyer(name, noTickets, show);
                        buyers.Add(buyer);
                    }
                }
            }
            //log.InfoFormat("Exiting findAlee with value {0}");
            return buyers;
        }

        public Buyer FindOne(int id)
        {
            //log.InfoFormat("Entering findOne with value {0}", id);
            IDbConnection con = DBUtils.getConnection();

            using (var comm = con.CreateCommand())
            {
                comm.CommandText = "select * from Buyers B inner join BuyerShow BS on B.idBuyer = BS.idBuyer inner join Shows S on S.idShow = BS.idShow where B.idbuyer = @id";
                IDbDataParameter paramId = comm.CreateParameter();
                paramId.ParameterName = "@id";
                paramId.Value = id;
                comm.Parameters.Add(paramId);

                using (var dataR = comm.ExecuteReader())
                {
                    if (dataR.Read())
                    {
                        int idBuyer = dataR.GetInt32(0);
                        int noTickets = dataR.GetInt32(1);
                        String name = dataR.GetString(2);

                        int idShow = dataR.GetInt32(5);
                        String artistName = dataR.GetString(6);
                        String place = dataR.GetString(7);
                        int remainingTickets = dataR.GetInt32(8);
                        DateTime date = DateTime.ParseExact(dataR.GetString(9), "yyyy-MM-dd HH:mm", null);

                        Show show = new Show(idShow, artistName, date, place, remainingTickets);
                        Buyer buyer = new Buyer(name, noTickets, show);
                        return buyer;
                    }
                }
            }
            //log.InfoFormat("Exiting findOne with value {0}", null);
            return null;
        }

        public Buyer Save(Buyer entity)
        {
            //log.InfoFormat("Entering save with value {0}", entity.Name);
            var con = DBUtils.getConnection();

            using (var comm = con.CreateCommand())
            {
                comm.CommandText = "INSERT INTO buyers (idBuyer, noTickets, name) VALUES  (@idBuyer, @noTickets, @name)";
                var paramId = comm.CreateParameter();
                paramId.ParameterName = "@idBuyer";
                paramId.Value = entity.ID;
                comm.Parameters.Add(paramId);

                var paramTickets = comm.CreateParameter();
                paramTickets.ParameterName = "@noTickets";
                paramTickets.Value = entity.noTickets;
                comm.Parameters.Add(paramTickets);

                var paramName = comm.CreateParameter();
                paramName.ParameterName = "@name";
                paramName.Value = entity.Name;
                comm.Parameters.Add(paramName);

                var result = comm.ExecuteNonQuery();

                if (result == 0)
                    throw new RepositoryException("No buyer added !");
                else
                {
                    comm.CommandText = "UPDATE shows SET remainingTickets = remainingTickets - @remainingTickets WHERE idShow = @idShow";

                    var paramTickets1 = comm.CreateParameter();
                    paramTickets1.ParameterName = "@remainingTickets";
                    paramTickets1.Value = entity.noTickets;
                    comm.Parameters.Add(paramTickets1);

                    var paramId1 = comm.CreateParameter();
                    paramId1.ParameterName = "@idShow";
                    paramId1.Value = entity.show.ID;
                    comm.Parameters.Add(paramId1);

                    comm.ExecuteNonQuery();


                    comm.CommandText = "INSERT INTO BuyerShow (idShow, idBuyer) VALUES (@idShow, @idBuyer)";

                    var paramIdShow = comm.CreateParameter();
                    paramIdShow.ParameterName = "@idShow";
                    paramIdShow.Value = entity.show.ID;
                    comm.Parameters.Add(paramIdShow);

                    var paramIdBuyer = comm.CreateParameter();
                    paramIdBuyer.ParameterName = "@idBuyer";
                    paramIdBuyer.Value = entity.ID;
                    comm.Parameters.Add(paramIdBuyer);

                    comm.ExecuteNonQuery();
                    return entity;
                }

            }
            //log.InfoFormat("Exiting save with value {0}", entity.Name);
        }
    }
}
