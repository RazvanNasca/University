﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    [Serializable]
    public class Show : Entity<int>
    {
        public Show(int id, string artistName, DateTime date, string place, int remainingTickets)
        {
            ID = id;
            ArtistName = artistName;
            Date = date;
            Place = place;
            RemainingTickets = remainingTickets;
        }

        public string ArtistName { get; set; }
        public DateTime Date { get; set; }
        public string Place { get; set; }
        public int RemainingTickets { get; set; }

        public override string ToString()
        {
            return ArtistName + " " + Date + " " + Place + " " + RemainingTickets;
        }
    }
}
