﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab2CSharp.Domain;

namespace Lab2CSharp.Repository
{
    interface IRepoUser : ICrudRepo<string, User>{}
}
