﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class LoginForm : Form
    {
        private FestivalClientCtrl ctrl;
        public LoginForm(FestivalClientCtrl ctrl)
        {
            InitializeComponent();
            this.ctrl = ctrl;
            passwordTextBox.UseSystemPasswordChar = true;
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            string username = usernameTextBox.Text;
            string password = passwordTextBox.Text;

            try
            {
                ctrl.login(username, password);
                MainForm chatWin = new MainForm(ctrl);
                chatWin.Text = "Chat window for " + username;
                chatWin.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                messageLabel.Text = ex.Message;
                messageLabel.ForeColor = Color.DarkRed;
            }
        }
    }
}
