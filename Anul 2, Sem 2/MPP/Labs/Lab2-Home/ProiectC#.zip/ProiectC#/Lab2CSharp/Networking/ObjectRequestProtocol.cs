﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Networking
{

	public interface Request
	{
	}


	[Serializable]
	public class LoginRequest : Request
	{
		private User user;

		public LoginRequest(User user)
		{
			this.user = user;
		}

		public virtual User User
		{
			get
			{
				return user;
			}
		}
	}

	[Serializable]
	public class LogoutRequest : Request
	{
		private User user;

		public LogoutRequest(User user)
		{
			this.user = user;
		}

		public virtual User User
		{
			get
			{
				return user;
			}
		}
	}

	[Serializable]
	public class GetFilteredShowsRequest : Request
	{
		private DateTime date;

		public GetFilteredShowsRequest(DateTime date)
		{
			this.date = date;
		}

		public virtual DateTime Date
		{
			get
			{
				return date;
			}
		}
	}

	[Serializable]
	public class SaveBuyerRequest : Request
    {
		private Buyer buyer;

		public SaveBuyerRequest(Buyer buyer)
        {
			this.buyer = buyer;
        }

		public virtual Buyer Buyer
        {
            get 
			{
				return buyer;
			}
        }
	}

	[Serializable]
	public class GetAllShowsRequest : Request
	{
		public GetAllShowsRequest()
        {
        }
	}

	[Serializable]
	public class GetLoggedUsersRequest : Request
	{
		public GetLoggedUsersRequest()
		{
		}

	}
}
