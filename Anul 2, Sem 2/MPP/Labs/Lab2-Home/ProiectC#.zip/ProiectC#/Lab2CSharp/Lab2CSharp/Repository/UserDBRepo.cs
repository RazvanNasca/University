﻿using Lab2CSharp.Domain;
using log4net;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2CSharp.Repository
{
    class UserDBRepo : IRepoUser
    {

		private static readonly ILog log = LogManager.GetLogger("UserDBRepo");
		public UserDBRepo()
		{
			log.Info("Creating UserDBRepo");
		}


		public IEnumerable<User> FindAll()
        {
			log.InfoFormat("Entering findAll ");
			IDbConnection con = DBUtils.getConnection();

			IList<User> users = new List<User>();

			using (var comm = con.CreateCommand())
			{
				comm.CommandText = "SELECT * FROM users";
				
				using (var dataR = comm.ExecuteReader())
				{
					while (dataR.Read())
					{
						String username = dataR.GetString(0);
						String password = dataR.GetString(1);

						User user = new User(username, password);
						users.Add(user);
					}
				}
			}
			log.InfoFormat("Exiting findAll");
			return users;
		}

        public User FindOne(string id)
        {
			log.InfoFormat("Entering findOne with value {0}", id);
			IDbConnection con = DBUtils.getConnection();

			using (var comm = con.CreateCommand())
			{
				comm.CommandText = "SELECT * FROM users WHERE name=@id";
				IDbDataParameter paramId = comm.CreateParameter();
				paramId.ParameterName = "@id";
				paramId.Value = id;
				comm.Parameters.Add(paramId);

				using (var dataR = comm.ExecuteReader())
				{
					if (dataR.Read())
					{
						String username = dataR.GetString(0);
						String password = dataR.GetString(1);

						User user = new User(username, password);
						log.InfoFormat("Exiting findOne with value {0}", user);
						return user;
					}
				}
			}
			log.InfoFormat("Exiting findOne with value {0}", null);
			return null;
		}

        public User Save(User entity)
        {
			log.InfoFormat("Entering save with value {0}", entity.Name);
			var con = DBUtils.getConnection();

			using (var comm = con.CreateCommand())
			{
				comm.CommandText = "INSERT INTO users(name, password) VALUES (@username, @password)";
				var paramId = comm.CreateParameter();
				paramId.ParameterName = "@username";
				paramId.Value = entity.Name;
				comm.Parameters.Add(paramId);

				var paramDesc = comm.CreateParameter();
				paramDesc.ParameterName = "@password";
				paramDesc.Value = entity.Password;
				comm.Parameters.Add(paramDesc);

				var result = comm.ExecuteNonQuery();
				if (result == 0)
					throw new RepositoryException("No user added !");

				
			}
			log.InfoFormat("Exiting save with value {0}", entity.Name);
			return null;
		}
    }
}
