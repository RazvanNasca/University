public class Main {
	
	public static void main(String[] args) throws InterruptedException {
		int a[] = {1,2,3,4,5,6,7,8,9,10};
		int b[] = {1,2,3,4,5,6,7,8,9,10};
		int c[] = new int[10];
		
		System.out.println("Hello form main 1");
		
		int p = 4;
		//int p = Integer.parseInt(args[0]);
		
		Thread[] t = new Worker[p]; 
		
		int start = 0;
		int end = 0;
		int chunk = c.length / p;
		int rest = c.length % p;
		
		long startTime = System.nanoTime();
		
		for(int i = 0; i < t.length; i++){
			
			end = start + chunk;
			
			if(rest > 0){
				end++;
				rest--;
			}
			
			t[i] = new Worker(i, start, end, a, b, c);
			t[i] = start();
			
			start = end;
		}
		
		// Thread t = new Worker();
		/// t.run(); nu se foloseste niciodata run
		/// t.start();
		
		System.out.println("Hello form main 2");
		
		for(int i = 0; i < t.length; i++){ /// bariera de sincronizare
			t[i].join();
		}
		
		long stopTime = System.nanoTime();
		double time = (double)(stopTime - startTime) / 1E6; /// milisecunde
		
		System.out.println(time);
	}	
	
}