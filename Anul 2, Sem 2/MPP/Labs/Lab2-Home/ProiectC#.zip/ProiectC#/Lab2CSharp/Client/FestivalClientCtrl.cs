﻿using Model;
using Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
    public class FestivalClientCtrl : IFestivalObserver
    {
        public event EventHandler<FestivalUserEventArgs> updateEvent;
        private readonly IFestivalServices server;
        private User currentUser;
        public FestivalClientCtrl(IFestivalServices server)
        {
            this.server = server;
            currentUser = null;
        }

        public void login(String userId, String pass)
        {
            User user = new User(userId, pass);
            server.Login(user, this);
            Console.WriteLine("Login succeeded ....");
            currentUser = user;
            Console.WriteLine("Current user {0}", user);
        }

        public void userLoggedIn(User user)
        {
            Console.WriteLine("User logged in " + user);
            FestivalUserEventArgs userArgs = new FestivalUserEventArgs(FestivalUserEvent.UserLoggedIn, user.ID);
            OnUserEvent(userArgs);
        }

        public void logout()
        {
            Console.WriteLine("Ctrl logout");
            server.logout(currentUser, this);
            currentUser = null;
        }

        public void userLoggedOut(User user)
        {
            Console.WriteLine("User logged out" + user);
            FestivalUserEventArgs userArgs = new FestivalUserEventArgs(FestivalUserEvent.UserLoggedOut, user.ID);
            OnUserEvent(userArgs);
        }

        /// ???
        public void SaveBuyer(String name,  int noTickets, Show show)
        {
            server.saveBuyer(name, noTickets, show);
            FestivalUserEventArgs userArgs = new FestivalUserEventArgs(FestivalUserEvent.ShowUpdated, show);
            OnUserEvent(userArgs);
            Console.WriteLine("Buyer saved...");
        }

        public void showUpdate(Show show)
        {
            Console.WriteLine("Show updated" + show);
            FestivalUserEventArgs userArgs = new FestivalUserEventArgs(FestivalUserEvent.ShowUpdated, show);
            OnUserEvent(userArgs);
        }

        protected virtual void OnUserEvent(FestivalUserEventArgs e)
        {
            if (updateEvent == null) 
                return;
            updateEvent(this, e);
            Console.WriteLine("Update Event called");
        }
        public IList<String> getLoggedUsers()
        {
            IList<String> loggedUsers = new List<string>();
            User[] users = server.getLoggedUsers();
            foreach (var user in users)
            {
                loggedUsers.Add(user.ID);
            }
            return loggedUsers;
        }

        public List<Show> getAllShows()
        {
            return server.getAllShows();
        }

        public List<Show> SearchArtistByDate(DateTime date)
        {
            return server.searchArtistByDate(date);
        }

    }
}
