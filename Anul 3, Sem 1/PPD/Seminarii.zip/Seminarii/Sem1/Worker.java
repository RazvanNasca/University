import java.lang.Math;
public class Worker extends Thread {
	
	private int i, start, end;
	
	private int[] a, b, c;
	
	public Worker(int i, int start, int end, int[] a, int[] b, int[] c){
		this.i = i; /// constructorul face workerul mai incet
		this.a = a;
		this.b = b;
		this.c = c;
		this.start = start;
		this.end = end;
	}
	
	@Override
	public void run() {
		/// super.run();
		
		System.out.println("Hello from thread" + i);
		
		for (int i = start; i < end; i++) {
			/// c[i] = a[i] + b[i];
			c[i] = (int)Math.sqrt(Math.pow(a[i], 4) + Math.pow(b[i], 4));
			/// timpul a fost putin mai lung, nu e mare diferenta
		}
	}
	
}