﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Persistance;
using Networking;
using System.Threading;
using System.Net.Sockets;
using Services;

namespace Server
{
    public class StartServer
    {
        static void Main(string[] args)
        {

            IRepoUser userRepo = new UserDBRepo();
            IRepoShow showRepo = new ShowDBRepo();
            IRepoBuyer buyerRepo = new BuyerDBRepo();
            IFestivalServices serviceImpl = new ServiceFestival(buyerRepo, showRepo, userRepo);

            // IChatServer serviceImpl = new ChatServerImpl();
            SerialFestivalServer server = new SerialFestivalServer("127.0.0.1", 55555, serviceImpl);
            server.Start();
            Console.WriteLine("Server started ...");
            //Console.WriteLine("Press <enter> to exit...");
            Console.ReadLine();

        }

        public class SerialFestivalServer : ConcurrentServer
        {
            private IFestivalServices server;
            private FestivalClientWorker worker;
            public SerialFestivalServer(string host, int port, IFestivalServices server) : base(host, port)
            {
                this.server = server;
                Console.WriteLine("SerialChatServer...");
            }
            protected override Thread createWorker(TcpClient client)
            {
                worker = new FestivalClientWorker(server, client);
                return new Thread(new ThreadStart(worker.run));
            }
        }

    }
}
