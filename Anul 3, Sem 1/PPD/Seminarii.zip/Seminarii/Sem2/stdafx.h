#pragma once

#include "targetver.h"

#include <stdio.h>;
#include <tchar.h>;
#include <iostream>;
#include <thread>;
#include <vector>;
#include <time.h>;
#include <cstdlib>;
#include <cmath>;
