﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class MainForm : Form
    {
        private readonly FestivalClientCtrl ctrl;
        private readonly IList<String> usersData;
        private readonly IList<Show> showsData;
        public MainForm(FestivalClientCtrl ctrl)
        {
            InitializeComponent();
            this.ctrl = ctrl;
            usersData = ctrl.getLoggedUsers();
            userList.DataSource = usersData;

            showsData = ctrl.getAllShows();

            ctrl.updateEvent += userUpdate;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.fillMainTable(null);
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Console.WriteLine("MainForm closing " + e.CloseReason);
            if (e.CloseReason == CloseReason.UserClosing)
            {
                ctrl.logout();
                ctrl.updateEvent -= userUpdate;
                Application.Exit();
            }

        }

        public void userUpdate(object sender, FestivalUserEventArgs e)
        {
            if (e.UserEventType == FestivalUserEvent.UserLoggedIn)
            {
                String userId = e.Data.ToString();
                usersData.Add(userId);
                Console.WriteLine("[FestivalWindow] userLoggedIn " + userId);
                userList.BeginInvoke(new UpdateListBoxCallback(this.updateListBox), new Object[] { userList, usersData });
                //   friendList.BeginInvoke((Action) delegate { friendList.DataSource = friendsData; });

            }
            if (e.UserEventType == FestivalUserEvent.UserLoggedOut)
            {
                String userId = e.Data.ToString();
                usersData.Remove(userId);
                Console.WriteLine("[FestivalWindow] userLoggedOut " + userId);
                userList.BeginInvoke(new UpdateListBoxCallback(this.updateListBox), new Object[] { userList, usersData });
            }

           
            if (e.UserEventType == FestivalUserEvent.ShowUpdated)
            {
                Show show = (Show)e.Data;
                /*showsData.Remove(show);*/
                Console.WriteLine("[FestivalWindow] showUpdated " + show);
                mainTable.BeginInvoke(new UpdateDataViewCallback(fillMainTable), new Object[] { show });
            }
        }

        public delegate void UpdateDataViewCallback(Show show);

        private void updateShowList(Show show)
        {
            foreach(Show s in showsData)
            {
                if (s.ID == show.ID)
                    s.RemainingTickets = show.RemainingTickets;
            }
        }

        //for updating the GUI

        //1. define a method for updating the ListBox
        private void updateListBox(ListBox listBox, IList<String> newData)
        {
            listBox.DataSource = null;
            listBox.DataSource = newData;
        }

        //2. define a delegate to be called back by the GUI Thread
        public delegate void UpdateListBoxCallback(ListBox list, IList<String> data); 

        

        //3. in the other thread call like this:
        /*
         * list.Invoke(new UpdateListBoxCallback(this.updateListBox), new Object[]{list, data});
         * 
         * */


        private void fillMainTable(Show s)
        {
            if(s != null)
            {
                updateShowList(s);
            }
            mainTable.Rows.Clear();
            
            foreach (Show show in showsData)
            {
                string[] row = new string[] { show.ArtistName, show.Place, show.Date.ToString(), show.RemainingTickets.ToString(), show.ID.ToString() };
                mainTable.Rows.Add(row);
            }
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            mainTable.Rows.Clear();
            IEnumerable<Show> shows = this.ctrl.SearchArtistByDate(dateTimePicker.Value);
            foreach (Show show in shows)
            {
                string[] row = new string[] { show.ArtistName, show.Place, show.Date.ToString(), show.RemainingTickets.ToString(), show.ID.ToString() };
                mainTable.Rows.Add(row);
            }
        }

        private void buyButton_Click(object sender, EventArgs e)
        {

            DateTime dateShow = DateTime.Parse(dateTextBox.Text, null);
            int ticketsShow = Int32.Parse(ticketsTextBox.Text);
            int idShow = Int32.Parse(idTextBox.Text);
            String artist = artistTextbox.Text;
            String place = locationTextBox.Text;

            Show show = new Show(idShow, artist, dateShow, place, ticketsShow);

            this.ctrl.SaveBuyer(buyerNameTextBox.Text, Decimal.ToInt32(noTicketsRequest.Value), show);
            ///fillMainTable(show);
        }

        private void mainTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            artistTextbox.Text = mainTable.Rows[e.RowIndex].Cells["artistName"].FormattedValue.ToString();
            locationTextBox.Text = mainTable.Rows[e.RowIndex].Cells["Location"].FormattedValue.ToString();
            dateTextBox.Text = mainTable.Rows[e.RowIndex].Cells["dateOfShow"].FormattedValue.ToString();
            ticketsTextBox.Text = mainTable.Rows[e.RowIndex].Cells["noTickets"].FormattedValue.ToString();
            idTextBox.Text = mainTable.Rows[e.RowIndex].Cells["idShow"].FormattedValue.ToString();

            mainTable.CurrentRow.Selected = true;
        }

        private void mainTable_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            artistTextbox.Text = mainTable.Rows[e.RowIndex].Cells["artistName"].FormattedValue.ToString();
            locationTextBox.Text = mainTable.Rows[e.RowIndex].Cells["Location"].FormattedValue.ToString();
            dateTextBox.Text = mainTable.Rows[e.RowIndex].Cells["dateOfShow"].FormattedValue.ToString();
            ticketsTextBox.Text = mainTable.Rows[e.RowIndex].Cells["noTickets"].FormattedValue.ToString();
            idTextBox.Text = mainTable.Rows[e.RowIndex].Cells["idShow"].FormattedValue.ToString();

            mainTable.CurrentRow.Selected = true;
        }

        private void logout_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you really want to exit?", "Dialog Title", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                ctrl.logout();
                Environment.Exit(0);
            }
        }
    }
}
