﻿using Lab2CSharp.Domain;
using log4net;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2CSharp.Repository
{
    class ShowDBRepo : IRepoShow
    {
        private static readonly ILog log = LogManager.GetLogger("ShowDBRepo");
        public ShowDBRepo()
        {
            log.Info("Creating ShowDBRepo");
        }

        public IEnumerable<Show> FindAll()
        {
            log.InfoFormat("Entering findAll");
            IDbConnection con = DBUtils.getConnection();

            IList<Show> shows = new List<Show>();

            using (var comm = con.CreateCommand())
            {
                comm.CommandText = "SELECT * FROM shows";

                using (var dataR = comm.ExecuteReader())
                {
                    while (dataR.Read())
                    {
                        int idShow = dataR.GetInt32(0);
                        String artistName = dataR.GetString(1);
                        String place = dataR.GetString(2);
                        int remainingTickets = dataR.GetInt32(3);
                        DateTime date = DateTime.ParseExact(dataR.GetString(4), "yyyy-MM-dd HH:mm", null);

                        Show show = new Show(idShow, artistName, date, place, remainingTickets);
                        shows.Add(show);
                    }
                }
            }
            log.InfoFormat("Exiting findOne with value {0}", null);
            return shows;
        }

        public Show FindOne(int id)
        {
            log.InfoFormat("Entering findOne with value {0}", id);
            IDbConnection con = DBUtils.getConnection();

            using (var comm = con.CreateCommand())
            {
                comm.CommandText = "SELECT * FROM shows WHERE idShow=@id";
                IDbDataParameter paramId = comm.CreateParameter();
                paramId.ParameterName = "@id";
                paramId.Value = id;
                comm.Parameters.Add(paramId);

                using (var dataR = comm.ExecuteReader())
                {
                    if (dataR.Read())
                    {
                        int idShow = dataR.GetInt32(0);
                        String artistName = dataR.GetString(1);
                        String place = dataR.GetString(2);
                        int remainingTickets = dataR.GetInt32(3);
                        DateTime date = DateTime.ParseExact(dataR.GetString(4), "yyyy-MM-dd HH:mm", null);

                        Show show = new Show(idShow, artistName, date, place, remainingTickets);
                        log.InfoFormat("Exiting findOne with value {0}", show);
                        return show;
                    }
                }
            }
            log.InfoFormat("Exiting findOne with value {0}", null);
            return null;
        }

        public Show Save(Show entity)
        {
            log.InfoFormat("Entering save with value {0}", entity.ArtistName);
            var con = DBUtils.getConnection();

            using (var comm = con.CreateCommand())
            {
                comm.CommandText = "INSERT INTO show (idShow, artistName, date, place, remainingtockets) VALUES  (@idShow, @artistName, @date, @place, @remainingtockets)";
                var paramId = comm.CreateParameter();
                paramId.ParameterName = "@idShow";
                paramId.Value = entity.ID;
                comm.Parameters.Add(paramId);

                var paramArtist = comm.CreateParameter();
                paramArtist.ParameterName = "@artistName";
                paramArtist.Value = entity.ArtistName;
                comm.Parameters.Add(paramArtist);
                
                var paramDate = comm.CreateParameter();
                paramDate.ParameterName = "@date";
                paramDate.Value = entity.ID;
                comm.Parameters.Add(paramDate);

                var paramPlace = comm.CreateParameter();
                paramPlace.ParameterName = "@place";
                paramPlace.Value = entity.ArtistName;
                comm.Parameters.Add(paramPlace);

                var paramTickets = comm.CreateParameter();
                paramTickets.ParameterName = "@remainingtockets";
                paramTickets.Value = entity.ArtistName;
                comm.Parameters.Add(paramTickets);

                var result = comm.ExecuteNonQuery();
                if (result == 0)
                    throw new RepositoryException("No show added !");


            }
            log.InfoFormat("Exiting save with value {0}", entity.ArtistName);
            return null;
        }

        public IEnumerable<Show> SearchArtistByDate(DateTime date)
        {
            log.InfoFormat("Entering SearchArtistByDate with value {0}", date);
            IDbConnection con = DBUtils.getConnection();

            String date_str = date.ToString("yyyy-MM-dd");
            date_str += "%";

            IList<Show> shows = new List<Show>();

            using (var comm = con.CreateCommand())
            {
                comm.CommandText = "SELECT * FROM shows WHERE date LIKE @date";
                IDbDataParameter paramDate = comm.CreateParameter();
                paramDate.ParameterName = "@date";
                paramDate.Value = date_str;
                comm.Parameters.Add(paramDate);

                using (var dataR = comm.ExecuteReader())
                {
                    while (dataR.Read())
                    {
                        int idShow = dataR.GetInt32(0);
                        String artistName = dataR.GetString(1);
                        String place = dataR.GetString(2);
                        int remainingTickets = dataR.GetInt32(3);
                        DateTime dateShow = DateTime.ParseExact(dataR.GetString(4), "yyyy-MM-dd HH:mm", null);

                        Show show = new Show(idShow, artistName, dateShow, place, remainingTickets);
                        log.InfoFormat("Exiting SearchArtistByDate with value {0}", artistName);
                        shows.Add(show);
                    }
                }
            }
            log.InfoFormat("Exiting SearchArtistByDate with value {0}", null);
            return shows;
        }
    }
}
