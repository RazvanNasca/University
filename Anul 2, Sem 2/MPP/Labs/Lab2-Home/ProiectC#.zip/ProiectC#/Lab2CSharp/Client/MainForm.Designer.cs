﻿namespace Client
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainTable = new System.Windows.Forms.DataGridView();
            this.artistName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.location = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateOfShow = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.noTickets = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idShow = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.searchButton = new System.Windows.Forms.Button();
            this.buyerName = new System.Windows.Forms.Label();
            this.noTicketsBuyed = new System.Windows.Forms.Label();
            this.noTicketsRequest = new System.Windows.Forms.NumericUpDown();
            this.buyerNameTextBox = new System.Windows.Forms.TextBox();
            this.buyButton = new System.Windows.Forms.Button();
            this.artistTextbox = new System.Windows.Forms.TextBox();
            this.locationTextBox = new System.Windows.Forms.TextBox();
            this.dateTextBox = new System.Windows.Forms.TextBox();
            this.ticketsTextBox = new System.Windows.Forms.TextBox();
            this.idTextBox = new System.Windows.Forms.TextBox();
            this.logout = new System.Windows.Forms.Button();
            this.userList = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.mainTable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.noTicketsRequest)).BeginInit();
            this.SuspendLayout();
            // 
            // mainTable
            // 
            this.mainTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.mainTable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.artistName,
            this.location,
            this.dateOfShow,
            this.noTickets,
            this.idShow});
            this.mainTable.Location = new System.Drawing.Point(100, 82);
            this.mainTable.Name = "mainTable";
            this.mainTable.RowHeadersWidth = 51;
            this.mainTable.RowTemplate.Height = 24;
            this.mainTable.Size = new System.Drawing.Size(554, 150);
            this.mainTable.TabIndex = 0;
            this.mainTable.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.mainTable_CellClick);
            this.mainTable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.mainTable_CellContentClick);
            // 
            // artistName
            // 
            this.artistName.HeaderText = "Artist";
            this.artistName.MinimumWidth = 6;
            this.artistName.Name = "artistName";
            this.artistName.Width = 125;
            // 
            // location
            // 
            this.location.HeaderText = "Location";
            this.location.MinimumWidth = 6;
            this.location.Name = "location";
            this.location.Width = 125;
            // 
            // dateOfShow
            // 
            this.dateOfShow.HeaderText = "Date";
            this.dateOfShow.MinimumWidth = 6;
            this.dateOfShow.Name = "dateOfShow";
            this.dateOfShow.Width = 125;
            // 
            // noTickets
            // 
            this.noTickets.HeaderText = "Tickets Remaining";
            this.noTickets.MinimumWidth = 6;
            this.noTickets.Name = "noTickets";
            this.noTickets.Width = 125;
            // 
            // idShow
            // 
            this.idShow.HeaderText = "ID";
            this.idShow.MinimumWidth = 6;
            this.idShow.Name = "idShow";
            this.idShow.Visible = false;
            this.idShow.Width = 125;
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(131, 347);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker.TabIndex = 1;
            // 
            // searchButton
            // 
            this.searchButton.Location = new System.Drawing.Point(238, 395);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(93, 23);
            this.searchButton.TabIndex = 3;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // buyerName
            // 
            this.buyerName.AutoSize = true;
            this.buyerName.Location = new System.Drawing.Point(404, 302);
            this.buyerName.Name = "buyerName";
            this.buyerName.Size = new System.Drawing.Size(84, 17);
            this.buyerName.TabIndex = 4;
            this.buyerName.Text = "Buyer name";
            // 
            // noTicketsBuyed
            // 
            this.noTicketsBuyed.AutoSize = true;
            this.noTicketsBuyed.Location = new System.Drawing.Point(404, 355);
            this.noTicketsBuyed.Name = "noTicketsBuyed";
            this.noTicketsBuyed.Size = new System.Drawing.Size(53, 17);
            this.noTicketsBuyed.TabIndex = 5;
            this.noTicketsBuyed.Text = "Tickets";
            // 
            // noTicketsRequest
            // 
            this.noTicketsRequest.Location = new System.Drawing.Point(534, 347);
            this.noTicketsRequest.Name = "noTicketsRequest";
            this.noTicketsRequest.Size = new System.Drawing.Size(120, 22);
            this.noTicketsRequest.TabIndex = 6;
            // 
            // buyerNameTextBox
            // 
            this.buyerNameTextBox.Location = new System.Drawing.Point(534, 302);
            this.buyerNameTextBox.Name = "buyerNameTextBox";
            this.buyerNameTextBox.Size = new System.Drawing.Size(120, 22);
            this.buyerNameTextBox.TabIndex = 7;
            // 
            // buyButton
            // 
            this.buyButton.Location = new System.Drawing.Point(573, 395);
            this.buyButton.Name = "buyButton";
            this.buyButton.Size = new System.Drawing.Size(81, 35);
            this.buyButton.TabIndex = 8;
            this.buyButton.Text = "Buy";
            this.buyButton.UseVisualStyleBackColor = true;
            this.buyButton.Click += new System.EventHandler(this.buyButton_Click);
            // 
            // artistTextbox
            // 
            this.artistTextbox.Location = new System.Drawing.Point(100, 252);
            this.artistTextbox.Name = "artistTextbox";
            this.artistTextbox.Size = new System.Drawing.Size(120, 22);
            this.artistTextbox.TabIndex = 9;
            this.artistTextbox.Visible = false;
            // 
            // locationTextBox
            // 
            this.locationTextBox.Location = new System.Drawing.Point(250, 252);
            this.locationTextBox.Name = "locationTextBox";
            this.locationTextBox.Size = new System.Drawing.Size(120, 22);
            this.locationTextBox.TabIndex = 10;
            this.locationTextBox.Visible = false;
            // 
            // dateTextBox
            // 
            this.dateTextBox.Location = new System.Drawing.Point(407, 252);
            this.dateTextBox.Name = "dateTextBox";
            this.dateTextBox.Size = new System.Drawing.Size(120, 22);
            this.dateTextBox.TabIndex = 11;
            this.dateTextBox.Visible = false;
            // 
            // ticketsTextBox
            // 
            this.ticketsTextBox.Location = new System.Drawing.Point(534, 252);
            this.ticketsTextBox.Name = "ticketsTextBox";
            this.ticketsTextBox.Size = new System.Drawing.Size(120, 22);
            this.ticketsTextBox.TabIndex = 12;
            this.ticketsTextBox.Visible = false;
            // 
            // idTextBox
            // 
            this.idTextBox.Location = new System.Drawing.Point(100, 280);
            this.idTextBox.Name = "idTextBox";
            this.idTextBox.Size = new System.Drawing.Size(77, 22);
            this.idTextBox.TabIndex = 13;
            this.idTextBox.Visible = false;
            // 
            // logout
            // 
            this.logout.Location = new System.Drawing.Point(561, 26);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(93, 23);
            this.logout.TabIndex = 14;
            this.logout.Text = "Logout";
            this.logout.UseVisualStyleBackColor = true;
            this.logout.Click += new System.EventHandler(this.logout_Click);
            // 
            // userList
            // 
            this.userList.FormattingEnabled = true;
            this.userList.ItemHeight = 16;
            this.userList.Location = new System.Drawing.Point(750, 84);
            this.userList.Name = "userList";
            this.userList.Size = new System.Drawing.Size(213, 148);
            this.userList.TabIndex = 15;
            this.userList.Visible = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(740, 450);
            this.Controls.Add(this.userList);
            this.Controls.Add(this.logout);
            this.Controls.Add(this.idTextBox);
            this.Controls.Add(this.ticketsTextBox);
            this.Controls.Add(this.dateTextBox);
            this.Controls.Add(this.locationTextBox);
            this.Controls.Add(this.artistTextbox);
            this.Controls.Add(this.buyButton);
            this.Controls.Add(this.buyerNameTextBox);
            this.Controls.Add(this.noTicketsRequest);
            this.Controls.Add(this.noTicketsBuyed);
            this.Controls.Add(this.buyerName);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.dateTimePicker);
            this.Controls.Add(this.mainTable);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.mainTable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.noTicketsRequest)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView mainTable;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.Label buyerName;
        private System.Windows.Forms.Label noTicketsBuyed;
        private System.Windows.Forms.NumericUpDown noTicketsRequest;
        private System.Windows.Forms.TextBox buyerNameTextBox;
        private System.Windows.Forms.Button buyButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn artistName;
        private System.Windows.Forms.DataGridViewTextBoxColumn location;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateOfShow;
        private System.Windows.Forms.DataGridViewTextBoxColumn noTickets;
        private System.Windows.Forms.DataGridViewTextBoxColumn idShow;
        private System.Windows.Forms.TextBox artistTextbox;
        private System.Windows.Forms.TextBox locationTextBox;
        private System.Windows.Forms.TextBox dateTextBox;
        private System.Windows.Forms.TextBox ticketsTextBox;
        private System.Windows.Forms.TextBox idTextBox;
        private System.Windows.Forms.Button logout;
        private System.Windows.Forms.ListBox userList;
    }
}