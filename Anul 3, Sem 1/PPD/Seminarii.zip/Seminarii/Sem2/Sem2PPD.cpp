// Sem2PPD.cpp : This file contains the 'main' function. Program execution begins and ends there.


#include "stdafx.h"
#define MAX 1000000
using namespace std;

double a[MAX];
double b[MAX];
double c[MAX];

void adunare(double a[], double b[], double c[], int start, int end) {
    for (size_t i = start; i < end; i++)
    {
        // c[i] = a[i] + b[i];
        c[i] = sqrt(pow(a[i], 4) + pow(b[i], 4));
    }
    return;
}

void adunare_ciclica(double a[], double b[], double c[], int nrThread, int p) {
    for (size_t i = nrThread; i < MAX; i+=p)
    {
        // c[i] = a[i] + b[i];
        c[i] = sqrt(pow(a[i], 4) + pow(b[i], 4));
    }
    return;
}


int main(int argc, char **argv)
{

    /* int a[] = { 1,2,3,4,5,6,7,8,9,10 };
    int b[] = { 1,2,3,4,5,6,7,8,9,10 };
    int c[MAX]; */

    for (size_t i = 0; i < MAX; i++)
    {
        a[i] = i;
        b[i] = MAX - i;
    }

    // adunare(a, b, c);

    // thread t(adunare, a,b,c);
    // t.join();

    int p = 1024;
    /// int p = atoi(argv[1]);
    vector <thread> t;

    clock_t startTime = clock();

    /// Liniar
   /* int start = 0, end = 0;
    int chunk = MAX / p;
    int rest = MAX % p;

    for (size_t i = 0; i < p; i++)
    {
        start = end;
        end = start + chunk + (rest-- > 0);
        /// if (rest > 0){end++;rest--;}
        thread thr = thread(adunare, a, b, c, start, end);
        t.push_back(move(thr));
    } */

    /// Ciclic
    for (size_t i = 0; i < p; i++)
    {
        thread thr = thread(adunare_ciclica, a, b, c, i, p);
        t.push_back(move(thr));
    }

    for (auto& th : t)
    {
        if(th.joinable())
            th.join();
    }

    clock_t endTime = clock();

    /*for (size_t i = 0; i < MAX; i++)
    {
        cout << c[i] << " ";
    }*/

    cout << endl;
    cout << (double)(endTime - startTime) / CLOCKS_PER_SEC;

    return 0;
}
