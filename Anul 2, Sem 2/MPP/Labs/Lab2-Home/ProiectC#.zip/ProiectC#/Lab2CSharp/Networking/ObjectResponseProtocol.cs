﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Networking
{
	public interface Response
	{
	}

	[Serializable]
	public class OkResponse : Response
	{

	}

	[Serializable]
	public class ErrorResponse : Response
	{
		private string message;

		public ErrorResponse(string message)
		{
			this.message = message;
		}

		public virtual string Message
		{
			get
			{
				return message;
			}
		}
	}

	[Serializable]
	public class GetLoggedUsersResponse : Response
	{
		private User[] users;

		public GetLoggedUsersResponse(User[] users)
		{
			this.users = users;
		}

		public virtual User[] Users
		{
			get
			{
				return users;
			}
		}
	}

	[Serializable]
	public class GetAllShowsResponse : Response
	{
		private List<Show> shows;

		public GetAllShowsResponse(List<Show> shows)
		{
			this.shows = shows;
		}

		public virtual List<Show> Shows
		{
			get
			{
				return shows;
			}
		}
	}

	[Serializable]
	public class GetFilteredShowsResponse : Response
	{
		private List<Show> shows;

		public GetFilteredShowsResponse(List<Show> shows)
		{
			this.shows = shows;
		}

		public virtual List<Show> Shows
		{
			get
			{
				return shows;
			}
		}
	}

	public interface UpdateResponse : Response
	{
	}

	[Serializable]
	public class UserLoggedInResponse : Response
	{
		private User user;

		public UserLoggedInResponse(User user)
		{
			this.user = user;
		}

		public virtual User User
		{
			get
			{
				return user;
			}
		}
	}

	[Serializable]
	public class UserLoggedOutResponse : UpdateResponse
	{
		private User user;

		public UserLoggedOutResponse(User user)
		{
			this.user = user;
		}

		public virtual User User
		{
			get
			{
				return user;
			}
		}
	}


    [Serializable]
    public class SaveBuyerResponse : UpdateResponse
    {
        private Show show;

        public SaveBuyerResponse(Show show)
        {
            this.show = show;
        }

        public virtual Show Show
        {
            get
            {
                return show;
            }
        }
    }
}
