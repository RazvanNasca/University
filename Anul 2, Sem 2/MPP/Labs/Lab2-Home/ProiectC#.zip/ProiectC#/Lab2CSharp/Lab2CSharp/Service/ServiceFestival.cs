﻿using Lab2CSharp.Domain;
using Lab2CSharp.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2CSharp.Service
{
    class ServiceFestival
    {
        private BuyerDBRepo buyerDBRepo;
        private ShowDBRepo showDBRepo;
        private UserDBRepo userDBRepo;

        public ServiceFestival(BuyerDBRepo buyerDBRepo, ShowDBRepo showDBRepo, UserDBRepo userDBRepo)
        {
            this.buyerDBRepo = buyerDBRepo;
            this.showDBRepo = showDBRepo;
            this.userDBRepo = userDBRepo;
        }

        public IEnumerable<Show> getAllShows()
        {
            return showDBRepo.FindAll();
        }

        public IEnumerable<Buyer> getAllBuyers()
        {
            return buyerDBRepo.FindAll();
        }

        public User Login(String username)
        {
            try{
                return userDBRepo.FindOne(username);
            }
            catch(Exception e)
            {
                throw new Exception("User not exist! " + e);
            }
        }

        public IEnumerable<Show> SearchArtistByDate(DateTime date)
        {
                try{
                    return showDBRepo.SearchArtistByDate(date);
                }
                catch(Exception e)
                {
                    throw new Exception("Repo error" + e);
            }
        }

        public Buyer SaveBuyer(String name, int noTickets, Show Show)
        {
            try{
                Buyer buyer = new Buyer(name, noTickets, Show);
                List<Buyer> list = (List<Buyer>)getAllBuyers();
                buyer.ID = list.Count() + 1;
                return buyerDBRepo.Save(buyer);
            }
            catch(Exception e)
            {
                throw new Exception("Repo error" + e);
            }
        }
    }
}
